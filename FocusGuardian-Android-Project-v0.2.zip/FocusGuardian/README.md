# Focus Guardian Android project — v0.2.0

## Added in this version
- Website/domain detection from text exposed by the foreground app's Accessibility tree.
- Expanded adult-content keyword and known-domain heuristics, plus user-defined terms and domains.
- Custom warning text.
- Basic counters for sessions, warnings, flagged domains and blocked-app events.
- Optional focus-session app blocking for user-entered Android package names.
- PIN-gated settings (SHA-256 hash stored locally).

## Important limitations
This is still a starter project, not a compiled or device-tested APK. Accessibility monitoring is best-effort and cannot guarantee coverage across every app. Many apps do not expose URL/title/text to Android Accessibility; video frames, images, audio and protected surfaces are not analyzed. Keyword/domain heuristics can miss content and can create false positives.

App blocking is a deterrent, not tamper-proof: it sends the device Home action when a configured package is detected during an active focus session. It does not uninstall, disable, or securely lock the other app. A user can turn off the Accessibility service in Android settings.

Statistics are local counters. Focus minutes are currently not accumulated into a verified completed-session duration; the minutes field is reserved for the next iteration. Do not interpret counters as a forensic browsing log.

## Setup
1. Open the project in Android Studio.
2. Sync Gradle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the APK.
5. Grant notifications. Open app > Enable / manage monitoring > enable Focus Guardian under Android Accessibility settings.
6. Open Settings (PIN protected) and configure warning, domains, keywords, package names and app blocking.
7. Start a focus session to activate app blocking.

## Package-name examples
Package names vary by phone and app version. Use Android app package IDs, not display names. Common examples include `com.google.android.youtube` for YouTube and `com.android.chrome` for Chrome. Adding a browser package to the block list blocks the entire browser during a focus session, not just adult pages.

## Privacy
All matching is performed locally. The app does not transmit browsing data or screen text. Accessibility permission is powerful; enable it only on your own device and review the service behavior.
