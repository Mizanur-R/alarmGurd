package com.example.focusguardian

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.security.MessageDigest
import java.util.Calendar

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("guardian", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AlertHelper.createChannel(this)
        showDashboard()
    }

    private fun showDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 36, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "🛡 Focus Guardian"
            textSize = 28f
        })
        root.addView(TextView(this).apply {
            text = "Personal focus protection • on-device processing"
            textSize = 14f
            setPadding(0, 8, 0, 20)
        })
        val stats = StatsStore(this)
        root.addView(TextView(this).apply {
            text = "Focus sessions: ${stats.sessions()}    Focus minutes: ${stats.minutes()}\\nWarnings: ${stats.warnings()}    Domains flagged: ${stats.domains()}"
            textSize = 16f
            setPadding(0, 8, 0, 18)
        })
        root.addView(Button(this).apply {
            text = "Enable / manage monitoring"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = if (prefs.getBoolean("focus_active", false)) "End focus session" else "Start 25-minute focus session"
            setOnClickListener {
                val active = !prefs.getBoolean("focus_active", false)
                prefs.edit().putBoolean("focus_active", active)
                    .putLong("focus_until", if (active) System.currentTimeMillis() + 25 * 60_000L else 0L).apply()
                if (active) StatsStore(this@MainActivity).startSession()
                Toast.makeText(this@MainActivity, if (active) "Focus session started" else "Focus session ended", Toast.LENGTH_SHORT).show()
                showDashboard()
            }
        })
        root.addView(Button(this).apply {
            text = "Settings (PIN protected)"
            setOnClickListener { requestSettingsPin() }
        })
        root.addView(Button(this).apply {
            text = "Set daily alarm"
            setOnClickListener { showAlarmPicker() }
        })
        root.addView(Button(this).apply {
            text = "Test warning"
            setOnClickListener { AlertHelper.showAlert(this@MainActivity, prefs.getString("warning_message", "Potential adult content detected. Close it and return to your focus task.")!!) }
        })
        root.addView(TextView(this).apply {
            text = "Monitoring is best-effort. Android only exposes text that an app makes available to Accessibility. Video frames and protected content may not be inspectable."
            textSize = 12f
            setPadding(0, 20, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun requestSettingsPin() {
        val hasPin = prefs.contains("pin_hash")
        val box = EditText(this).apply {
            hint = if (hasPin) "Enter PIN" else "Create a PIN (at least 4 digits)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialogBuilder(this).showPin(box, hasPin) { entered ->
            if (!hasPin) {
                if (entered.length < 4) {
                    Toast.makeText(this, "PIN must contain at least 4 digits", Toast.LENGTH_LONG).show()
                    return@showPin
                }
                prefs.edit().putString("pin_hash", hash(entered)).apply()
                showSettings()
            } else if (hash(entered) == prefs.getString("pin_hash", "")) {
                showSettings()
            } else {
                Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showSettings() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
        }
        fun addLabel(s: String) { layout.addView(TextView(this).apply { text=s; textSize=15f; setPadding(0,12,0,4) }) }
        val warning = EditText(this).apply {
            hint = "Custom warning message"
            setText(prefs.getString("warning_message", "Potential adult content detected. Close it and return to your focus task."))
        }
        addLabel("Custom warning message")
        layout.addView(warning)

        val domains = EditText(this).apply {
            hint = "One domain per line, e.g. example.com"
            minLines = 3
            setText(prefs.getString("blocked_domains", ""))
        }
        addLabel("Extra domains to flag (one per line)")
        layout.addView(domains)

        val apps = EditText(this).apply {
            hint = "Android package names, one per line"
            minLines = 3
            setText(prefs.getString("blocked_apps", ""))
        }
        addLabel("Apps to block during focus sessions")
        layout.addView(apps)

        val terms = EditText(this).apply {
            hint = "Extra detection keywords, one per line"
            minLines = 3
            setText(prefs.getString("extra_terms", ""))
        }
        addLabel("Extra detection keywords")
        layout.addView(terms)

        val enableBlocking = CheckBox(this).apply {
            text = "Enforce app blocking during active focus sessions"
            isChecked = prefs.getBoolean("app_blocking", false)
        }
        layout.addView(enableBlocking)

        val scroll = ScrollView(this).apply { addView(layout) }
        android.app.AlertDialog.Builder(this)
            .setTitle("Protection settings")
            .setView(scroll)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putString("warning_message", warning.text.toString().ifBlank { "Potential adult content detected. Close it and return to your focus task." })
                    .putString("blocked_domains", domains.text.toString())
                    .putString("blocked_apps", apps.text.toString())
                    .putString("extra_terms", terms.text.toString())
                    .putBoolean("app_blocking", enableBlocking.isChecked)
                    .apply()
                Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
                showDashboard()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun showAlarmPicker() {
        val time = TimePicker(this).apply { setIs24HourView(true) }
        android.app.AlertDialog.Builder(this).setTitle("Daily focus alarm").setView(time)
            .setPositiveButton("Save") { _, _ ->
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, time.hour); set(Calendar.MINUTE, time.minute)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                }
                scheduleDailyAlarm(cal.timeInMillis)
            }.setNegativeButton("Cancel", null).show()
    }

    private fun scheduleDailyAlarm(triggerAt: Long) {
        val pi = PendingIntent.getBroadcast(this, 1001, Intent(this, FocusAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val manager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !manager.canScheduleExactAlarms()) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply { data = Uri.parse("package:$packageName") })
            Toast.makeText(this, "Allow exact alarms, then set the alarm again.", Toast.LENGTH_LONG).show()
            return
        }
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, triggerAt, AlarmManager.INTERVAL_DAY, pi)
        Toast.makeText(this, "Daily alarm saved", Toast.LENGTH_SHORT).show()
    }

    private fun hash(value: String): String =
        MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}

private class AlertDialogBuilder(private val activity: Activity) {
    fun showPin(input: EditText, hasPin: Boolean, onSubmit: (String) -> Unit) {
        android.app.AlertDialog.Builder(activity)
            .setTitle(if (hasPin) "Unlock settings" else "Create settings PIN")
            .setView(input)
            .setPositiveButton(if (hasPin) "Unlock" else "Create") { _, _ -> onSubmit(input.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }
}
