package com.example.focusguardian

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class ContentMonitorService : AccessibilityService() {
    private var lastAlertAt = 0L
    private var lastBlockedAt = 0L

    private val adultTerms = listOf(
        "porn", "xxx", "adult video", "explicit content", "nudity", "nude",
        "sex video", "18+", "hentai", "onlyfans", "erotic", "nsfw",
        "hardcore", "cam girl", "adult entertainment"
    )
    private val knownAdultDomains = listOf(
        "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn",
        "brazzers", "chaturbate", "onlyfans", "spankbang", "tube8"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences("guardian", MODE_PRIVATE)
        val now = SystemClock.elapsedRealtime()
        val packageName = event.packageName?.toString().orEmpty()

        // Focus-session app blocking is opt-in and only applies to package names entered by the user.
        val focusActive = prefs.getBoolean("focus_active", false) &&
            System.currentTimeMillis() < prefs.getLong("focus_until", 0L)
        if (prefs.getBoolean("app_blocking", false) && focusActive) {
            val blocked = prefs.getString("blocked_apps", "").orEmpty()
                .lines().map { it.trim() }.filter { it.isNotBlank() }
            if (packageName in blocked && now - lastBlockedAt > 4_000) {
                lastBlockedAt = now
                performGlobalAction(GLOBAL_ACTION_HOME)
                AlertHelper.showAlert(this, "This app is paused during your focus session.")
                StatsStore(this).recordBlock()
                return
            }
        }

        if (now - lastAlertAt < 20_000) return
        val chunks = mutableListOf<String>()
        event.text?.forEach { chunks.add(it?.toString().orEmpty()) }
        event.contentDescription?.toString()?.let { chunks.add(it) }
        event.source?.let { collectVisibleText(it, chunks, 0) }
        val visible = chunks.joinToString(" ").lowercase(Locale.ROOT)

        val extraTerms = prefs.getString("extra_terms", "").orEmpty().lines()
            .map { it.trim().lowercase(Locale.ROOT) }.filter { it.length >= 3 }
        val domains = prefs.getString("blocked_domains", "").orEmpty().lines()
            .map { it.trim().lowercase(Locale.ROOT).removePrefix("https://").removePrefix("http://") }
            .filter { it.isNotBlank() }
        val urlRegex = Regex("""(?i)(?:https?://)?(?:www\\.)?([a-z0-9-]+(?:\\.[a-z0-9-]+)+)""")
        val foundDomains = urlRegex.findAll(visible).map { it.groupValues[1].lowercase(Locale.ROOT) }.toList()
        val matchedTerm = (adultTerms + extraTerms).firstOrNull { visible.contains(it) }
        val matchedDomain = (knownAdultDomains + domains).firstOrNull { d ->
            foundDomains.any { it == d || it.endsWith(".$d") } || visible.contains(d)
        }

        if (matchedTerm != null || matchedDomain != null) {
            lastAlertAt = now
            StatsStore(this).recordWarning(matchedDomain != null)
            val message = prefs.getString("warning_message",
                "Potential adult content detected. Close it and return to your focus task.")
                ?: "Potential adult content detected."
            AlertHelper.showAlert(this, message)
        }
    }

    private fun collectVisibleText(node: AccessibilityNodeInfo, out: MutableList<String>, depth: Int) {
        if (depth > 12 || out.size > 250) return
        node.text?.toString()?.let { if (it.isNotBlank()) out.add(it) }
        node.contentDescription?.toString()?.let { if (it.isNotBlank()) out.add(it) }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collectVisibleText(child, out, depth + 1)
                child.recycle()
            }
        }
    }

    override fun onInterrupt() {}
}
