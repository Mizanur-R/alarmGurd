package com.example.focusguardian

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class FocusAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        AlertHelper.showAlert(context, "Your scheduled focus alarm is ringing. Return to your priority task.")
    }
}
