package com.example.focusguardian

import android.content.Context

class StatsStore(context: Context) {
    private val p = context.getSharedPreferences("guardian_stats", Context.MODE_PRIVATE)
    fun sessions() = p.getInt("sessions", 0)
    fun minutes() = p.getLong("minutes", 0L)
    fun warnings() = p.getInt("warnings", 0)
    fun domains() = p.getInt("domains", 0)
    fun blocks() = p.getInt("blocks", 0)

    fun startSession() {
        p.edit().putInt("sessions", sessions() + 1)
            .putLong("session_started", System.currentTimeMillis()).apply()
    }
    fun recordWarning(domain: Boolean) {
        p.edit().putInt("warnings", warnings() + 1)
            .putInt("domains", domains() + if (domain) 1 else 0).apply()
    }
    fun recordBlock() { p.edit().putInt("blocks", blocks() + 1).apply() }
}
